console.log('hi');
console.log(document.querySelector(".title"))
console.log('hi')
let draft = document.querySelector(".draft");
let draftone = document.querySelector(".draftone");
console.log(draft)
let videogames = document.querySelector(".videogames");
let buttton1 = document.querySelector(".basketball");
// let question1 = 
let button= document.querySelector("button");
let bcontainer= document.querySelector(".hiddenDiv");

                                        

button.onclick= function (){
  let userInput= document.querySelector(".question1").value; 
  document.querySelector(".name").innerHTML=" Hi " + userInput + "! Nice to meet you. Keep scrolling down ↓";
  bcontainer.style.display= "block";
}



