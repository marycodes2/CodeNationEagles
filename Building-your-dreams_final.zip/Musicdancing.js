let h1= document.querySelector(".dancer")
let h3= document.querySelector("h3")
let h2=document.querySelector ("h2")
let singer= document.querySelector(".Singer")
  
h1.onclick= function () {
  h3.style.display="none";
  h2.innerHTML=" You are not supposed to click here 😮‍💨 ";
}

singer.onclick= function () {
  document.body.style.backgroundColor= "#B69bb9";
}

