let draft = document.querySelector(".draft");
let draftone = document.querySelector(".draftone");
let Curry = document.querySelector(".Curry");
let Achievement1 = document.querySelector(".Achievement1");
let Achievement = document.querySelector(".Achievement");
let success = document.querySelector(".success");
let successful = document.querySelector(".successful");
let background = document.querySelector("body");
let home = document.querySelector("home");
draftone.onclick = function (){
  console.log("working!")
   draft.style.display="block";
  Curry.style.display="none";
  background.style.background = "#ff80b3";
}
Achievement1.onclick = function (){
   Achievement.style.display="block";
  draft.style.display="none";
  background.style.background = "#ffff99";
}
success.onclick = function (){
   successful.style.display="block";
  Achievement.style.display="none";
  background.style.background = "linear-gradient(lightblue, pink)";
}

